# OT Reminders
This plugin let you set reminders that will be sent to a channel every specified time.
You can set the reminder message, the channel where it will be sent, the time between reminders, and the time when the first reminder will be sent by slash command.