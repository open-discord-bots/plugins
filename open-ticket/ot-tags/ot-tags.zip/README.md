# OT Tags
Use tags to quickly reply with a pre-existing text! Or let the bot answer automatically based on keywords.

### Smart Mode VS default
By default a message is required to match all keywords.

Using smart mode, the bot will send the tag when around 70% of the keywords are matched (and a few other rules).