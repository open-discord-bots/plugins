# OT Customise Buttons
Customise almost all built-in buttons. This includes the claim, reopen, close & delete buttons!