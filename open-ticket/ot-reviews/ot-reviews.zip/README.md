# OT Reviews
Review system for Open Ticket! It is very customisable and has lots of features.

> ### Review Modes
> How much reviews can someone create?
> - `"one-per-ticket" - Create 1 review per ticket created.
> - `"unlimited-per-ticket" - Create unlimited reviews, but at least 1 ticket needs to be created.
> - `"unrestricted" - Everyone can create an unlimited amount of reviews.