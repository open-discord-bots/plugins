# Example Command
A simple example plugin to create a custom command using the Open Ticket API.

> Use this plugin as a starter template for adding a custom command to Open Ticket!