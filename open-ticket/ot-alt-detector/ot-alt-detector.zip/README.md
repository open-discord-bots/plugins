# OT Alt Detector
Use the discord-alt-detector npm package by DJdj Development in your ticket bot!

> This package uses the `discord-alt-detector` npm package.
> More info about this package can be found there.
>
> https://www.npmjs.com/package/discord-alt-detector