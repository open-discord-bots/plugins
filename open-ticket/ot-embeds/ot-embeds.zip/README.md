# OT Embeds
Create custom premade embeds in the config or use the /embed command to create one in the server!