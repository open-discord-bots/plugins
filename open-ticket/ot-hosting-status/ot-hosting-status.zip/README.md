# OT Hosting Status
A simple command to send hosting status updates to a channel.