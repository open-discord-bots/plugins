# OT No Slash Clear
Disable the automatic removal of slash commands that aren't used by Open Discord bots.

> This plugin is made for people that want to create their own slash commands but don't want to use the Open Discord system!