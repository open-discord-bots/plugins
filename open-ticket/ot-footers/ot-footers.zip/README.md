# OT Footers
A simple plugin to add footers in all Open Ticket embeds. This also includes panels & ticket messages!

> ### Overwriting Footers
> Embeds with their own footers will not be overwritten. This will result in some embeds not having the custom footer!