# OT Ephemeral Messages
Customise which messages need to be ephemeral and which ones not. This includes claim, reopen, close & delete messages!

### Warning!
This plugin doesn't work when using buttons or text commands! Only when using slash-commands.
This is because the way Open Ticket responds to the interactions is different for commands & buttons.

### Integration
This plugin also has integrations for the following plugins:
- OT Config Reload
- OT Jump To Top
- OT Kill Switch