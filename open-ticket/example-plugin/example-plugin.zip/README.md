# Example Plugin
A simple example of an Open Ticket v4 plugin!

> Use this plugin as a starter template for all your custom plugins!